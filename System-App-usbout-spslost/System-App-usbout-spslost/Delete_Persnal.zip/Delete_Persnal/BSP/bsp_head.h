#ifndef __BSP_HEAD_H_
#define __BSP_HEAD_H_

#include "main.h"
#include <stdio.h>

#include "bsp_emmc.h"
#include "ads1285.h"
#include "um980.h"
#include "data_fusion.h"
#include "ads_1.h"
#include "usbd_core.h"

extern USBD_HandleTypeDef hUsbDeviceHS;

#endif